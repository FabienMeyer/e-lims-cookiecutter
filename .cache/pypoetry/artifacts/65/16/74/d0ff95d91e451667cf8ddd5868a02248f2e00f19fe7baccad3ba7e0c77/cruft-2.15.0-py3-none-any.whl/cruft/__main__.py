from cruft import _cli

_cli.app(prog_name="cruft")
